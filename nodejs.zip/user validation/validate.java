import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Validate extends HttpServlet
{
    protected void processRequest(HttpServletRequest request,
                                  HttpServletResponse response)
            throws ServletException, IOException
    {
        response.setContentType("text/html;charset=UTF-8");

        try(PrintWriter out = response.getWriter())
        {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con =
                DriverManager.getConnection(
                    "jdbc:mysql://localhost/test123",
                    "root",
                    ""
                );

                 Statement st = con.createStatement();

            st.execute(
                "CREATE TABLE IF NOT EXISTS users(" +
                "uname VARCHAR(30)," +
                "pwd VARCHAR(30))"
            );

            st.executeUpdate(
                "INSERT IGNORE INTO users VALUES('admin','123')"
            );

            String uname = request.getParameter("username");
            String pwd = request.getParameter("userpass");

            PreparedStatement ps =
                con.prepareStatement(
                    "select * from users where uname=? and pwd=?"
                );

            ps.setString(1, uname);
            ps.setString(2, pwd);

            ResultSet rs = ps.executeQuery();

            if(rs.next())
                out.println("Authorized User : " + uname);
            else
                out.println("Unauthorized User");

            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    protected void doGet(HttpServletRequest req,
                         HttpServletResponse res)
            throws ServletException, IOException
    {
        processRequest(req,res);
    }

    protected void doPost(HttpServletRequest req,
                          HttpServletResponse res)
            throws ServletException, IOException
    {
        processRequest(req,res);
    }
}