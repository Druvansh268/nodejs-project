<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>JSP Page</title>
</head>
<body>

<%
    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con =
        DriverManager.getConnection(
            "jdbc:mysql://localhost/test123",
            "root",
            ""
        );

    if(con != null)
    {
        out.println("Connected");
    }
    else
    {
        out.println("Unable to Connect");
    }

    con.close();
%>

</body>
</html>