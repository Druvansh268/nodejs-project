<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>JSP Page</title>
</head>
<body>

<%
    Cookie c1 = new Cookie("cse1", "mgit");
    Cookie c2 = new Cookie("nodejs", "cbit");

    response.addCookie(c1);
    response.addCookie(c2);

    out.println("Cookies are Added");
    out.println("<br>");
    out.println("<a href='c2.jsp'>C2</a>");
%>

</body>
</html>