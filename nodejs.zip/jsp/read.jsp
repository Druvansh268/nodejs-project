<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<html>
<body>

<%
String name = request.getParameter("t1");
String pwd = request.getParameter("p1");

out.println(name + "<br>");
out.println(pwd);
%>

</body>
</html>