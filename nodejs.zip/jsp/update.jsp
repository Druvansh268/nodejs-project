<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.Statement" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Update Data</title>
</head>
<body>

<%
    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con =
        DriverManager.getConnection(
            "jdbc:mysql://localhost/test123",
            "root",
            ""
        );

    if(con != null)
    {
        out.println("Connected<br>");

        Statement s =
            con.createStatement();

        String q =
            "update student set stud_address='kkkk' " +
            "where stud_name='nnn'";

        s.execute(q);

        out.println("Data Updated...");

        s.close();
        con.close();
    }
    else
    {
        out.println("Unable to Connect");
    }
%>

</body>
</html>