<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.Statement" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Create Table</title>
</head>
<body>

<%
    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con =
        DriverManager.getConnection(
            "jdbc:mysql://localhost/test123",
            "root",
            ""
        );

    if(con != null)
    {
        out.println("Connected<br>");

        Statement stmt =
            con.createStatement();

        String q =
            "create table student(" +
            "stud_id integer," +
            "stud_name varchar(20)," +
            "stud_address varchar(30))";

        stmt.execute(q);

        out.println("Table Created...");

        stmt.close();
        con.close();
    }
    else
    {
        out.println("Unable to Connect");
    }
%>

</body>
</html>