<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>JSP Page</title>
</head>
<body>

<%
    String var1 =
            (String)session.getAttribute("cse1");

    String var2 =
            (String)session.getAttribute("nodejs");

    out.println("cse1 : " + var1);
    out.println("<br>");

    out.println("nodejs : " + var2);
%>

</body>
</html>