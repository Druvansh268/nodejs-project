<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>JSP Page</title>
</head>
<body>

<%
    Cookie c[] = request.getCookies();

    if(c != null)
    {
        for(Cookie c1 : c)
        {
            out.println(c1.getName()
                    + " : "
                    + c1.getValue());

            out.println("<br>");
        }
    }
%>

</body>
</html>