<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>JSP Page</title>
</head>
<body>

<%
    session.setAttribute("cse1", "mgit");
    session.setAttribute("nodejs", "jsp");

    out.println("Session Data Stored");
    out.println("<br>");
    out.println("<a href='s2.jsp'>S2</a>");
%>

</body>
</html>