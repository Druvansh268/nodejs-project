<%@ page import="java.sql.Connection" %>
<%@ page import="java.sql.DriverManager" %>
<%@ page import="java.sql.Statement" %>
<%@ page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Insert Data</title>
</head>
<body>

<%
    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con =
        DriverManager.getConnection(
            "jdbc:mysql://localhost/test123",
            "root",
            ""
        );

    if(con != null)
    {
        out.println("Connected<br>");

        Statement s =
            con.createStatement();

        s.execute(
            "insert into student values(2,'Raju','Hyd')"
        );

        s.execute(
            "insert into student values(3,'Ramesh','Hyd')"
        );

        out.println("Data Inserted...");

        s.close();
        con.close();
    }
    else
    {
        out.println("Unable to Connect");
    }
%>

</body>
</html>